import React from 'react';

const Profile = () => {
  return (
    <div>
      <p>Это контент страницы Профиля</p>
    </div>
  );
}

export default Profile;