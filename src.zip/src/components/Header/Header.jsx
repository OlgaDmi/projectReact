import React from 'react';
import Menu from '../Menu/Menu';
import PropTypes from 'prop-types';
import logo from './logo.svg';
import './style.scss';

const Header = (props) => {
    return (
        <header className="App-header">
          <img src={logo} alt="Logo"/>
        <Menu onChangePage={props.onChangePage}/>
        </header>
    );
  }
  
  Header.propTypes = {
    onChangePage: PropTypes.func
  };

  export default Header;